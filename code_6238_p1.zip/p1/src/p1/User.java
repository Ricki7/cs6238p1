package p1;

import java.math.BigInteger;

public class User {
	private String user_name;
	private String table_mapping;
	private String history_mapping;
	private BigInteger r;
	
}
