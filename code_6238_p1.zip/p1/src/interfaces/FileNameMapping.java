package interfaces;

public interface FileNameMapping {
	abstract String getMappingName(String name);
}
